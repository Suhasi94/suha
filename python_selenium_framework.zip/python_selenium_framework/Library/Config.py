class Config:
    URL = 'http://demowebshop.tricentis.com/'
    BROWSER_NAME = "Chrome"
    USERNAME = ""
    PASSWORD = ""
    FIREFOX_DRIVER_PATH = r""
    EDGE_DRIVER_PATH = r""
    CHROME_DRIVER_PATH = r"C:\Users\User\PycharmProjects\python_selenium_framework\Library\chromedriver.exe"
    IE_DRIVER_PATH = r""
    DATA_FILE_PATH = r"C:\Users\User\PycharmProjects\python_selenium_framework\Data\TestData.xls"
    OBJECTS_FILE_PATH = r"C:\Users\User\PycharmProjects\python_selenium_framework\Data\Objects.xls"

